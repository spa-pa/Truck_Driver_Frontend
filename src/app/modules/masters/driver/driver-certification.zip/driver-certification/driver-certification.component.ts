// src/app/modules/masters/driver-certification/driver-certification.component.ts

import {
  Component,
  Input,
  OnInit,
  OnDestroy,
  ViewChild,
  ElementRef,
} from "@angular/core";
import { CommonModule } from "@angular/common";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import { DriverCertification } from "@shared/models/driver-certification.model";
import { QRDisplayComponent } from "../../QR-Operation/qr-code/qr-display/qr-display.component";
import { Subscription } from "rxjs";
import { DriverCertificationService } from "@shared/_http/driver-certification.service";

@Component({
  selector: "app-driver-certification",
  standalone: true,
  imports: [CommonModule, QRDisplayComponent],
  templateUrl: "./driver-certification.component.html",
  styleUrls: ["./driver-certification.component.scss"],
})
export class DriverCertificationComponent implements OnInit, OnDestroy {
  @ViewChild("certificationCard") certificationCard!: ElementRef;
  @ViewChild(QRDisplayComponent) qrDisplayComponent!: QRDisplayComponent;
  @Input() certificationId: string = "";
  @Input() autoLoad: boolean = true;

  certificationDetailsId: any;
  certification: DriverCertification | null = null;
  isLoading: boolean = false;
  error: string | null = null;

  isDownloading: boolean = false;

  subs: any;
  qrConfig: any = {
    data: "",
    qrColor: "#004761",
    bgColor: "#ffffff",
    qrSize: 150,
    dotType: "rounded",
    bottomText: "Driver Certification",
    textSize: 12,
    textColor: "#004761",
    fontFamily: "Inter, sans-serif",
    fontWeight: "normal",
  };

  constructor(private driverCertificationService: DriverCertificationService) { }

  ngOnInit(): void {
    this.subs = new Subscription();
    if (this.autoLoad && this.certificationId) {
      this.loadCertification();
    }
  }

  ngOnDestroy(): void {
    if (this.subs) {
      this.subs.unsubscribe();
    }
  }

  loadCertification(): void {
    if (!this.certificationId) {
      this.error = "No certification ID provided";
      return;
    }

    this.isLoading = true;
    this.error = null;

    this.subs.add(
      this.driverCertificationService
        .getDriverCertificationByCertificationId(this.certificationId)
        .subscribe({
          next: (value) => {
            this.certification = value.data;
            this.isLoading = false;
            this.updateQRCode();
            setTimeout(() => this.updateQRCode(), 100);
          },
          error: (err) => {
            console.error("Error loading certification:", err);
            this.isLoading = false;
            this.error =
              err.error?.message ||
              "Failed to load certification details. Please try again.";
          },
        }),
    );
  }

  private updateQRCode(): void {
    if (!this.certification) return;

    const qrData = {
      certification_id: this.certification.certification_id,
    };

    this.qrConfig = {
      data: JSON.stringify(qrData),
    };

    this.certificationDetailsId = {
      ...this.qrConfig,
    };
  }

  // ============ DRIVER PHOTO ============

  getDriverPhotoUrl(): string | null {
    return (this.certification as any)?.driving_img_path || null;
  }

  // ============ EXPIRY HELPERS ============

  isExpired(): boolean {
    if (!this.certification) return false;
    const expiryDate = new Date(this.certification.expiry_date);
    return expiryDate < new Date();
  }

  isExpiringSoon(): boolean {
    if (!this.certification) return false;
    const days = this.getDaysUntilExpiry(this.certification.expiry_date);
    return days !== null && days <= 30 && days > 0;
  }

  getDaysUntilExpiry(dateString: string): number | null {
    if (!dateString) return null;
    const expiry = new Date(dateString);
    const today = new Date();
    const diffTime = expiry.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  }

  getExpiryProgress(): number {
    if (!this.certification) return 0;
    const totalDays = 365;
    const daysLeft =
      this.getDaysUntilExpiry(this.certification.expiry_date) || 0;
    const progress = ((totalDays - daysLeft) / totalDays) * 100;
    return Math.min(Math.max(progress, 0), 100);
  }

  // ============ GET QR CODE FROM QR DISPLAY COMPONENT ============
  private async getQRCodeFromComponent(): Promise<string> {
    // Wait for QR component to be available
    let attempts = 0;
    const maxAttempts = 20;

    while (attempts < maxAttempts) {
      if (this.qrDisplayComponent) {
        // Try to get QR data URL from component
        const dataURL = this.qrDisplayComponent.getQRDataURLSync();
        if (dataURL && dataURL.length > 100) {
          console.log('QR code obtained from component, size:', dataURL.length);
          return dataURL;
        }

        // Try async method
        try {
          const asyncDataURL = await this.qrDisplayComponent.getQRDataURLAsync();
          if (asyncDataURL && asyncDataURL.length > 100) {
            console.log('QR code obtained from component async, size:', asyncDataURL.length);
            return asyncDataURL;
          }
        } catch (e) {
          console.warn('Async QR retrieval failed:', e);
        }

        // Try to get canvas directly
        const canvas = this.qrDisplayComponent.getQRCanvas();
        if (canvas && canvas.width > 0 && canvas.height > 0) {
          try {
            const dataUrl = canvas.toDataURL('image/png');
            if (dataUrl && dataUrl.length > 100) {
              console.log('QR code obtained from canvas, size:', dataUrl.length);
              return dataUrl;
            }
          } catch (e) {
            console.warn('Failed to get QR from canvas:', e);
          }
        }
      }

      attempts++;
      console.log(`Waiting for QR code... attempt ${attempts}/${maxAttempts}`);
      await new Promise(resolve => setTimeout(resolve, 200));
    }

    // If all attempts fail, generate new QR
    console.log('All attempts failed, generating new QR...');
    return this.generateQRCodeImage();
  }

  private generateQRCodeImage(): Promise<string> {
    return new Promise((resolve, reject) => {
      import('qr-code-styling').then((module) => {
        const QRCodeStyling = module.default;

        const qrData = {
          certification_id: this.certification?.certification_id || ''
        };

        const qrCode = new QRCodeStyling({
          width: 250,
          height: 250,
          data: JSON.stringify(qrData),
          margin: 10,
          dotsOptions: {
            color: '#004761',
            type: 'rounded'
          },
          backgroundOptions: {
            color: '#ffffff'
          },
          cornersSquareOptions: {
            type: 'extra-rounded'
          },
          cornersDotOptions: {
            type: 'dot'
          }
        });

        const container = document.createElement('div');
        container.style.position = 'fixed';
        container.style.top = '0';
        container.style.left = '0';
        container.style.width = '250px';
        container.style.height = '250px';
        container.style.background = '#ffffff';
        container.style.zIndex = '9999';
        container.style.padding = '10px';
        container.style.borderRadius = '8px';
        container.style.boxShadow = '0 4px 12px rgba(0,0,0,0.2)';
        document.body.appendChild(container);

        let attempts = 0;
        const maxAttempts = 30;

        const checkCanvas = () => {
          const canvasElement = container.querySelector('canvas');
          const canvas = canvasElement as HTMLCanvasElement | null;

          if (canvas && canvas.width > 0 && canvas.height > 0) {
            try {
              const dataUrl = canvas.toDataURL('image/png');
              document.body.removeChild(container);
              resolve(dataUrl);
            } catch (error) {
              document.body.removeChild(container);
              reject(error);
            }
          } else if (attempts >= maxAttempts) {
            document.body.removeChild(container);
            reject(new Error('QR code generation timeout'));
          } else {
            attempts++;
            setTimeout(checkCanvas, 100);
          }
        };

        try {
          qrCode.append(container);
          setTimeout(checkCanvas, 300);
        } catch (error) {
          document.body.removeChild(container);
          reject(error);
        }
      }).catch((error) => {
        reject(error);
      });
    });
  }

  // ============ DOWNLOAD PDF ============

  private readonly PDF_WIDTH = 800;
  private readonly PDF_SCALE = 2;
  private readonly PDF_JPEG_QUALITY = 0.85;

  async downloadPDF(): Promise<void> {
    if (this.isDownloading) return;
    this.isDownloading = true;

    try {
      // Get QR code from the QRDisplayComponent
      let qrImageData = '';
      try {
        qrImageData = await this.getQRCodeFromComponent();
      } catch (error) {
        console.warn('QR generation failed, using fallback:', error);
        qrImageData = await this.createFallbackQR();
      }

      // Build PDF content
      const pdfContent = this.buildPDFContent(qrImageData);

      const pdfContainer = document.createElement('div');
      pdfContainer.style.width = `${this.PDF_WIDTH}px`;
      pdfContainer.style.background = '#ffffff';
      pdfContainer.style.padding = '20px';
      pdfContainer.style.boxSizing = 'border-box';
      pdfContainer.style.fontFamily = 'Arial, sans-serif';
      pdfContainer.innerHTML = pdfContent;

      const wrapper = document.createElement('div');
      wrapper.style.position = 'fixed';
      wrapper.style.top = '0';
      wrapper.style.left = '-99999px';
      wrapper.style.width = `${this.PDF_WIDTH}px`;
      wrapper.style.background = '#ffffff';
      wrapper.style.zIndex = '-1';
      wrapper.style.pointerEvents = 'none';
      wrapper.appendChild(pdfContainer);
      document.body.appendChild(wrapper);

      await new Promise(resolve => setTimeout(resolve, 500));

      const canvas = await html2canvas(pdfContainer, {
        scale: this.PDF_SCALE,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        logging: false,
        imageTimeout: 0,
        width: this.PDF_WIDTH,
        windowWidth: this.PDF_WIDTH,
      });

      if (wrapper.parentNode) {
        document.body.removeChild(wrapper);
      }

      const imageData = canvas.toDataURL('image/jpeg', this.PDF_JPEG_QUALITY);
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
        compress: true,
      });

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 8;

      const pxToMm = 25.4 / 96;
      const contentWidthMm = this.PDF_WIDTH * pxToMm;
      const contentHeightMm = (canvas.height / canvas.width) * this.PDF_WIDTH * pxToMm;

      const availableWidth = pageWidth - margin * 2;
      const availableHeight = pageHeight - margin * 2;
      const ratio = Math.min(
        availableWidth / contentWidthMm,
        availableHeight / contentHeightMm,
      );

      const renderWidth = contentWidthMm * ratio;
      const renderHeight = contentHeightMm * ratio;
      const x = (pageWidth - renderWidth) / 2;
      const y = margin;

      pdf.addImage(
        imageData,
        'JPEG',
        x,
        y,
        renderWidth,
        renderHeight,
        undefined,
        'NONE',
      );

      pdf.save(
        `Driver-Certification-${this.certification?.certification_id || 'Unknown'}.pdf`,
      );

    } catch (error) {
      console.error('PDF download error:', error);
      try {
        await this.downloadPDFLastResort();
      } catch (fallbackError) {
        console.error('Last resort PDF download error:', fallbackError);
      }
    } finally {
      this.isDownloading = false;
    }
  }

  // ============ BUILD PDF CONTENT ============
  private buildPDFContent(qrImageData: string): string {
    const c = this.certification;
    if (!c) return '';

    const isActive = this.isCertificationActive();
    const isLicenseExpired = this.isLicenseExpired();
    const isCertExpired = this.isExpired();
    const daysUntilExpiry = this.getDaysUntilExpiry(c.expiry_date);
    const expiryProgress = this.getExpiryProgress();

    const licenseExpiryDate = new Date(c.driving_license_expiry_date);
    const formattedLicenseExpiry = licenseExpiryDate.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });

    const expiryDate = new Date(c.expiry_date);
    const formattedExpiry = expiryDate.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });

    const createdDate = new Date(c.created_at);
    const formattedCreated = createdDate.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });

    const modifiedDate = new Date(c.modified_at || c.created_at);
    const formattedModified = modifiedDate.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });

    const activeText = isActive ? '✓ VALID' : '✗ EXPIRED';
    const ribbonBg = isActive ? '#10b981' : '#ef4444';
    const ribbonShadow = isActive ? 'rgba(16,185,129,0.3)' : 'rgba(239,68,68,0.3)';

    const licenseExpiryColor = isLicenseExpired ? '#ef4444' : '#004761';
    const certExpiryColor = isCertExpired ? '#ef4444' : '#004761';
    const progressColor = isCertExpired ? '#ef4444' : '#10b981';
    const daysColor = isCertExpired ? '#ef4444' : '#10b981';

    const photoHtml = this.getDriverPhotoUrl()
      ? `<img src="${this.getDriverPhotoUrl()}" style="width:100%;height:100%;object-fit:cover;" />`
      : '<div style="font-size:36px;color:#999;opacity:0.3;display:flex;align-items:center;justify-content:center;width:100%;height:100%;">👤</div>';

    const licenseDaysDisplay = this.getLicenseDaysDisplay();
    const daysRemaining = daysUntilExpiry !== null ? `${daysUntilExpiry} days remaining` : 'N/A';

    const qrSrc = qrImageData && qrImageData.length > 100 ? qrImageData : '';

    return `
      <div style="max-width:100%;background:#ffffff;border-radius:20px;border:2px solid #004761;padding:30px;position:relative;font-family:Arial,sans-serif;">
        <div style="position:absolute;top:20px;right:-30px;transform:rotate(45deg);padding:4px 44px;background:${ribbonBg};color:#ffffff;font-size:10px;font-weight:700;letter-spacing:1px;text-transform:uppercase;box-shadow:0 2px 10px ${ribbonShadow};">
          ${activeText}
        </div>

        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:15px;">
          <div>
            <div style="font-size:10px;color:#666;text-transform:uppercase;letter-spacing:0.5px;">Certification No.</div>
            <div style="font-size:16px;font-weight:700;color:#004761;">#${c.certification_id}</div>
          </div>
          <div style="text-align:right;">
            <h1 style="font-size:22px;font-weight:700;color:#004761;margin:0;text-transform:uppercase;">Driver Certification</h1>
            <p style="font-size:12px;color:#666;margin:2px 0 0;letter-spacing:1px;">Official Document of Verification</p>
          </div>
        </div>

        <div style="text-align:center;margin:10px 0;position:relative;">
          <span style="display:inline-block;padding:0 12px;background:#ffffff;color:#d4af37;font-size:12px;">✦</span>
          <div style="position:absolute;top:50%;left:0;right:0;height:1px;background:#eee;z-index:-1;"></div>
        </div>

        <div style="display:flex;align-items:center;justify-content:center;gap:30px;margin:10px 0;">
          <div style="text-align:center;">
            <div style="width:80px;height:80px;border-radius:50%;border:3px solid #eee;overflow:hidden;margin:0 auto;background:#f5f7fa;display:flex;align-items:center;justify-content:center;">
              ${photoHtml}
            </div>
            <div style="margin-top:4px;font-size:13px;font-weight:600;color:#004761;">${c.full_name}</div>
          </div>
          <div style="width:1px;height:70px;background:#eee;"></div>
          <div style="text-align:center;">
            <div style="display:inline-block;padding:4px;background:#ffffff;border-radius:8px;border:2px solid #eee;">
              ${qrSrc ? `<img src="${qrSrc}" style="width:120px;height:120px;display:block;object-fit:contain;" />` :
        `<div style="width:120px;height:120px;display:flex;align-items:center;justify-content:center;background:#f5f7fa;border-radius:4px;font-size:12px;color:#666;">QR Code</div>`}
            </div>
            <div style="margin-top:3px;font-size:9px;color:#666;font-weight:500;letter-spacing:0.5px;">Scan to Verify</div>
          </div>
        </div>

        <!-- Rest of the content remains the same -->
        <div style="text-align:center;margin:10px 0;position:relative;">
          <span style="display:inline-block;padding:0 12px;background:#ffffff;color:#d4af37;font-size:12px;">✦</span>
          <div style="position:absolute;top:50%;left:0;right:0;height:1px;background:#eee;z-index:-1;"></div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:10px 0;">
          <div style="display:flex;align-items:center;gap:10px;padding:6px 12px;background:#f5f7fa;border-radius:8px;border:1px solid #eee;min-height:40px;">
            <div style="font-size:14px;color:#004761;width:24px;text-align:center;">👤</div>
            <div style="flex:1;min-width:0;">
              <div style="font-size:7px;font-weight:500;color:#666;text-transform:uppercase;letter-spacing:0.3px;">Full Name</div>
              <div style="font-size:12px;font-weight:600;color:#004761;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${c.full_name}</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:10px;padding:6px 12px;background:#f5f7fa;border-radius:8px;border:1px solid #eee;min-height:40px;">
            <div style="font-size:14px;color:#004761;width:24px;text-align:center;">📱</div>
            <div style="flex:1;min-width:0;">
              <div style="font-size:7px;font-weight:500;color:#666;text-transform:uppercase;letter-spacing:0.3px;">Mobile Number</div>
              <div style="font-size:12px;font-weight:600;color:#004761;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${c.mobile_number}</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:10px;padding:6px 12px;background:#f5f7fa;border-radius:8px;border:1px solid #eee;min-height:40px;">
            <div style="font-size:14px;color:#004761;width:24px;text-align:center;">🏢</div>
            <div style="flex:1;min-width:0;">
              <div style="font-size:7px;font-weight:500;color:#666;text-transform:uppercase;letter-spacing:0.3px;">Terminal</div>
              <div style="font-size:12px;font-weight:600;color:#004761;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${c.terminal_name}</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:10px;padding:6px 12px;background:#f5f7fa;border-radius:8px;border:1px solid #eee;min-height:40px;">
            <div style="font-size:14px;color:#004761;width:24px;text-align:center;">💳</div>
            <div style="flex:1;min-width:0;">
              <div style="font-size:7px;font-weight:500;color:#666;text-transform:uppercase;letter-spacing:0.3px;">License Number</div>
              <div style="font-size:12px;font-weight:600;color:#004761;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${c.driving_license_number}</div>
            </div>
          </div>
        </div>

        <div style="text-align:center;margin:10px 0;position:relative;">
          <span style="display:inline-block;padding:0 12px;background:#ffffff;color:#d4af37;font-size:12px;">✦</span>
          <div style="position:absolute;top:50%;left:0;right:0;height:1px;background:#eee;z-index:-1;"></div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:10px 0;">
          <div style="display:flex;align-items:center;gap:10px;padding:8px 14px;background:#f5f7fa;border-radius:10px;border:1px solid ${isLicenseExpired ? '#ef4444' : '#eee'};">
            <div style="font-size:14px;color:#004761;width:24px;text-align:center;">📅</div>
            <div style="flex:1;min-width:0;">
              <div style="font-size:7px;font-weight:500;color:#666;text-transform:uppercase;letter-spacing:0.3px;">License Expiry</div>
              <div style="font-size:13px;font-weight:700;color:${licenseExpiryColor};">${formattedLicenseExpiry}</div>
              <div style="font-size:8px;font-weight:500;color:${isLicenseExpired ? '#ef4444' : '#10b981'};">${licenseDaysDisplay}</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:10px;padding:8px 14px;background:#f5f7fa;border-radius:10px;border:1px solid ${isCertExpired ? '#ef4444' : '#f59e0b'};">
            <div style="font-size:14px;color:#004761;width:24px;text-align:center;">⚠️</div>
            <div style="flex:1;min-width:0;">
              <div style="font-size:7px;font-weight:500;color:#666;text-transform:uppercase;letter-spacing:0.3px;">Certification Expiry</div>
              <div style="font-size:13px;font-weight:700;color:${certExpiryColor};">${formattedExpiry}</div>
              <div style="font-size:8px;font-weight:500;color:${daysColor};">${daysRemaining}</div>
            </div>
          </div>
        </div>

        <div style="margin:10px 0;">
          <div style="width:100%;height:4px;background:#eee;border-radius:4px;overflow:hidden;">
            <div style="height:100%;width:${expiryProgress}%;background:${progressColor};border-radius:4px;"></div>
          </div>
          <div style="display:flex;justify-content:space-between;margin-top:2px;font-size:8px;color:#666;">
            <span>Issued</span>
            <span>${Math.round(expiryProgress)}%</span>
            <span>Expired</span>
          </div>
        </div>

        <div style="display:flex;justify-content:space-between;align-items:center;padding-top:10px;border-top:1px solid #eee;margin-top:auto;">
          <div style="display:flex;gap:14px;flex-wrap:wrap;">
            <div style="display:flex;align-items:center;gap:5px;font-size:9px;color:#666;">
              <span>📅</span>
              <span>Issued: ${formattedCreated}</span>
            </div>
            <div style="display:flex;align-items:center;gap:5px;font-size:9px;color:#666;">
              <span>🔍</span>
              <span>Verified: ${formattedModified}</span>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // ============ CREATE FALLBACK QR ============
  private async createFallbackQR(): Promise<string> {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      canvas.width = 200;
      canvas.height = 200;
      const ctx = canvas.getContext('2d');

      if (ctx) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, 200, 200);

        const size = 16;
        for (let row = 0; row < 12; row++) {
          for (let col = 0; col < 12; col++) {
            const isFilled = (row + col) % 2 === 0 || (row % 3 === 0 && col % 3 === 0);
            ctx.fillStyle = isFilled ? '#004761' : '#ffffff';
            ctx.fillRect(col * size + 8, row * size + 8, size - 2, size - 2);
          }
        }

        ctx.fillStyle = '#004761';
        ctx.fillRect(8, 8, 48, 48);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(16, 16, 32, 32);
        ctx.fillStyle = '#004761';
        ctx.fillRect(24, 24, 16, 16);

        ctx.fillStyle = '#004761';
        ctx.fillRect(144, 8, 48, 48);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(152, 16, 32, 32);
        ctx.fillStyle = '#004761';
        ctx.fillRect(160, 24, 16, 16);

        ctx.fillStyle = '#004761';
        ctx.fillRect(8, 144, 48, 48);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(16, 152, 32, 32);
        ctx.fillStyle = '#004761';
        ctx.fillRect(24, 160, 16, 16);

        ctx.fillStyle = '#004761';
        ctx.fillRect(80, 80, 40, 40);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(88, 88, 24, 24);

        resolve(canvas.toDataURL('image/png'));
      } else {
        const dataUrl = 'data:image/svg+xml,' + encodeURIComponent(`
          <svg xmlns="http://www.w3.org/2000/svg" width="200" height="200">
            <rect width="200" height="200" fill="white"/>
            <rect x="10" y="10" width="180" height="180" rx="8" fill="#004761" opacity="0.1"/>
            <text x="100" y="100" text-anchor="middle" fill="#004761" font-size="16" font-family="Arial">QR Code</text>
            <text x="100" y="120" text-anchor="middle" fill="#666" font-size="10" font-family="Arial">${this.certification?.certification_id || ''}</text>
          </svg>
        `);
        resolve(dataUrl);
      }
    });
  }

  // ============ LAST RESORT FALLBACK ============
  private async downloadPDFLastResort(): Promise<void> {
    const original = this.certificationCard?.nativeElement as HTMLElement;
    if (!original) return;

    const clone = original.cloneNode(true) as HTMLElement;
    clone.querySelectorAll('canvas').forEach(c => c.remove());
    clone.querySelectorAll('.btn-download, .btn-print').forEach(b => b.remove());

    const wrapper = document.createElement('div');
    wrapper.style.position = 'fixed';
    wrapper.style.top = '0';
    wrapper.style.left = '-99999px';
    wrapper.style.width = '800px';
    wrapper.style.background = '#ffffff';
    wrapper.style.zIndex = '-1';
    wrapper.appendChild(clone);
    document.body.appendChild(wrapper);

    await new Promise(resolve => setTimeout(resolve, 500));

    const canvas = await html2canvas(clone, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff',
      logging: false,
      imageTimeout: 0,
    });

    if (wrapper.parentNode) {
      document.body.removeChild(wrapper);
    }

    const imageData = canvas.toDataURL('image/jpeg', 0.85);
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true,
    });

    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const margin = 8;

    const imgWidth = canvas.width;
    const imgHeight = canvas.height;
    const pxToMm = 25.4 / 96;
    const contentWidthMm = imgWidth * pxToMm;
    const contentHeightMm = imgHeight * pxToMm;

    const availableWidth = pageWidth - margin * 2;
    const availableHeight = pageHeight - margin * 2;
    const ratio = Math.min(
      availableWidth / contentWidthMm,
      availableHeight / contentHeightMm,
    );

    const renderWidth = contentWidthMm * ratio;
    const renderHeight = contentHeightMm * ratio;
    const x = (pageWidth - renderWidth) / 2;
    const y = margin;

    pdf.addImage(imageData, 'JPEG', x, y, renderWidth, renderHeight);
    pdf.save(`Driver-Certification-${this.certification?.certification_id || 'Unknown'}.pdf`);
  }

  printCertification(): void {
    const element = this.certificationCard?.nativeElement;
    if (!element) return;

    const printWindow = window.open("", "_blank", "width=800,height=600");
    if (!printWindow) {
      alert("Please allow popups for printing");
      return;
    }

    const styles = Array.from(document.querySelectorAll("style"))
      .map((style) => style.innerHTML)
      .join("");

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Driver Certification</title>
          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
          <style>
            body { margin: 0; padding: 20px; background: #ffffff; font-family: Arial, sans-serif; }
            .print-container { max-width: 900px; margin: 0 auto; }
            ${styles}
            .certification-card { box-shadow: none !important; border: 2px solid #004761 !important; }
            .btn-download, .btn-print, .footer-right { display: none !important; }
            .pdf-export .footer-right { display: none !important; }
          </style>
        </head>
        <body>
          <div class="print-container">${element.outerHTML}</div>
          <script>
            window.onload = function() { window.print(); window.close(); };
          <\/script>
        </body>
      </html>
    `;

    printWindow.document.write(html);
    printWindow.document.close();
  }

  refresh(): void {
    this.loadCertification();
  }

  getDaysUntilExpirySafe(dateString: string): number {
    const days = this.getDaysUntilExpiry(dateString);
    return days !== null ? days : 0;
  }

  isCertificationActive(): boolean {
    if (!this.certification || !this.certification.expiry_date) {
      return false;
    }

    const expiryDate = new Date(this.certification.expiry_date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    expiryDate.setHours(0, 0, 0, 0);

    return expiryDate >= today;
  }

  isCertificationExpired(): boolean {
    return !this.isCertificationActive();
  }

  isLicenseExpired(): boolean {
    const days = this.getLicenseDaysUntilExpiry();
    return days !== null && days <= 0;
  }

  getLicenseDaysUntilExpiry(): number | null {
    if (
      !this.certification ||
      !this.certification.driving_license_expiry_date
    ) {
      return null;
    }

    const expiryDate = new Date(this.certification.driving_license_expiry_date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    expiryDate.setHours(0, 0, 0, 0);

    const diffTime = expiryDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    return diffDays;
  }

  getLicenseDaysDisplay(): string {
    const days = this.getLicenseDaysUntilExpiry();
    if (days === null) {
      return "N/A";
    }
    if (days > 0) {
      return `${days} days remaining`;
    }
    return `EXPIRED ${Math.abs(days)} days ago`;
  }
}